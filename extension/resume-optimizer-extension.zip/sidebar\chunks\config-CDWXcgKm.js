const p="http://resume-optimizer-production-2600.up.railway.app";export{p as A};
